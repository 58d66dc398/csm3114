import 'package:flutter/material.dart';
import 'question.dart';
import 'answer.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<StatefulWidget> createState() {
    return MyAppState();
  }
}

class MyAppState extends State<MyApp> {
  var questionIndex = 0;

  List<Map<String, Object>> questions = [
    {
      'question': "What's your favorite colour?",
      'answers': ['red', 'blue']
    },
    {
      'question': "What's your favorite animal?",
      'answers': ['dog', 'cat']
    },
    {
      'question': "What's your preferred type of discount?",
      'answers': ['student', 'teacher']
    }
  ];

  void answerQuestion() {
    // print('Chose answer');

    setState(() {
      if (++questionIndex >= questions.length) {
        questionIndex = 0;
      }

      print(questionIndex);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: AppBar(title: const Text('Quiz App')),
      body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Text(
              //   questions[questionIndex]['question'].toString(),
              //   style:
              //       const TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
              // ),
              Question(questions[questionIndex]['question'].toString()),
              // ElevatedButton(
              //     onPressed: answerQuestion, child: const Text('Answer 1')),
              // ElevatedButton(
              //     onPressed: answerQuestion, child: const Text('Answer 2')),
              // OutlinedButton(
              //     onPressed: answerQuestion, child: const Text('Answer 3'))
              // ...answers.map((answer) => ElevatedButton(
              //       onPressed: answerQuestion,
              //       child: Text(answer),
              //     )),
              ...(questions[questionIndex]['answers'] as List<String>)
                  .map((answer) => Answer(answerQuestion, answer)),
            ],
          )),
    ));
  }
}
